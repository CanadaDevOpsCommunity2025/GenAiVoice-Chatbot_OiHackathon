"""
Text-to-Text AI Assistant Modules
This package contains all the modular components of the AI assistant.
""" 